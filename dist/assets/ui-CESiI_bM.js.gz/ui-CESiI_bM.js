import"./vendor-eQ4gZK-n.js";
